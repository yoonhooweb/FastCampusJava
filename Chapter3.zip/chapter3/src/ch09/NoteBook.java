package ch09;

public abstract class NoteBook extends Computer{

	@Override
	public void display() {
		System.out.println("NoteBook display");
		
	}
	
}
